//
//  MovieGridCell.swift
//  flixster
//
//  Created by geek on 12/6/19.
//  Copyright © 2019 annievan2000. All rights reserved.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    @IBOutlet weak var posterView: UIImageView!
    
}
